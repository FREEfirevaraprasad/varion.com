
function talk() {
    const input = document.getElementById('userInput').value;
    let response = "Lyra AI: You said '" + input + "'.";
    document.getElementById('response').innerText = response;
}
